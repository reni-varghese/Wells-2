package org.reni.security;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import jakarta.validation.Valid;

@Component
public class JwtTokenProvider {
	@Value("${app.jwt.secret}")
	private String jwtSecret;
	@Value("${app.jwt.expiration-milliseconds}")
	private long expiryTime;
	
	

}
