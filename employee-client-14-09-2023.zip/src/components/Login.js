import {useState} from "react";
import {login} from "./api";
import {useNavigate} from "react-router-dom";

const Login=()=>{
    const navigate=useNavigate();
    const [usernameOrEmail, setUsernameOrEmail] = useState('')
    const [password, setPassword] = useState('')
    const [errorMessage, setErrorMessage] = useState('');

    const handleUsernameChange=(e)=>{
        setUsernameOrEmail(e.target.value);
    }
    const handlePasswordChange=(e)=>{
        setPassword(e.target.value);
    }

    const onLogin=async (e)=>{
        e.preventDefault();

        const loginDetails={
            usernameOrEmail,
            password
        }
        console.log(loginDetails)
        // try{
        //     const result=await login(loginDetails)
        //     localStorage.setItem("token",result.accessToken);
        //     navigate("/list")
        // }
        // catch(error){
        //     if(error.response.status===401){
        //         setErrorMessage("Invalid User name or password");
        //     }
        // }
         login(loginDetails).then(result=>{
             console.log(result);
             navigate("/list")
         })
             .catch(error=> {
                 if(error.response.status===401){
                     setErrorMessage("Invalid username or password");
                 }
             })



    }



    return (
        <div className="container">
            <h6 className="text-danger">{errorMessage}</h6>
            <form className="col-4" onSubmit={onLogin}>
                <div>
                    <label className="form-label">User Name</label>
                    <input type="text" className="form-control" onChange={handleUsernameChange}/>
                </div>
                <div>
                    <label className="form-label">Password</label>
                    <input type="password" className="form-control" onChange={handlePasswordChange}/>
                </div>

                <br/>
                <button className="btn btn-primary">Login</button>
            </form>
        
        </div>
    )
}

export default Login;