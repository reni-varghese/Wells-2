import { Link } from "react-router-dom";

const MainNavigation = () => {
  return (
    <nav className="navbar navbar-expand navbar-dark bg-dark">
      <div className="container">
        <a href="#" className="navbar-brand">
          MyCompany Inc
        </a>
        <ul className="navbar-nav">
          <li className="nav-item">
            <Link to="/" className="nav-link">
              Login
            </Link>
          </li>
          <li className="nav-item">
            <Link to="/list" className="nav-link">
              List Employees
            </Link>
          </li>
          <li className="nav-item">
            <Link to="/add" className="nav-link">
              Add Employee
            </Link>
          </li>
        </ul>
      </div>
    </nav>
  );
};

export default MainNavigation;
