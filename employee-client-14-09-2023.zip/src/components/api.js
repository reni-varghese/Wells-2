import axios from "axios";
const addEmployee = async (employee) => {
    const token=localStorage.getItem("token");
    const bearerToken=`Bearer ${token}`
    console.log("Bearer Token============",bearerToken);
    console.log("Token from post request  "+token);
  const response = await axios.post(
    "http://localhost:8080/api/employees",
    employee,{
        headers:{
            Authorization: bearerToken
        }

      }
  );
};

const getAll = async () => {
  const response = await axios.get("http://localhost:8080/api/employees");
  console.log("This is from get All", response.data);
  return response.data;
};

const login=async (loginDetails)=>{
   const response=await axios.post("http://localhost:8080/api/auth/login",loginDetails);
   return response.data;
}

const getById=async (id)=>{
    const response=await axios.get(`http://localhost:8080/api/employees/${id}`)
    return response.data;
}

const deleteEmployee=async (id)=>{
   const response= await axios.delete(`http://localhost:8080/api/employees/${id}`);
}

const updateEmployee=async (id,employee)=>{
    const res=await axios.put(`http://localhost:8080/api/employees/${id}`,employee)
    return res.data;
}

export { addEmployee, getAll,login,getById,deleteEmployee,updateEmployee };
