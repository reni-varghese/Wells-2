import { useEffect, useState } from "react";
import { getAll } from "./api";
import {Link, useNavigate} from "react-router-dom";

const EmployeeList = () => {
  const [employees, setEmployees] = useState([]);
  const navigate=useNavigate();

  useEffect(() => {
    return async () => {
      const response = await getAll();
      setEmployees(response);

    };
  }, []);

  const onLogout=()=>{
    localStorage.removeItem("token");
    console.log("token",localStorage.getItem("token"))
    console.log("You logged out successfully");
  }

  const onDelete=(id)=>{
      console.log(id);
      navigate(`/delete/${id}`)
  }

  return (
    <div className="container">
      <h3 className="text-primary">Employee List</h3>
      <table className="table table-striped table-bordered">
        <thead>
          <tr>

            <th>Name</th>
            <th>Gender</th>
            <th>Age</th>
            <th>Salary</th>
            <th>Email</th>
            <th>Date of Joining</th>
            <th>Mobile</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {employees.map((employee) => (
            <tr key={employee.id}>

              <td>{employee.name}</td>
              <td>{employee.gender}</td>
              <td>{employee.age}</td>
              <td>{employee.salary}</td>
              <td>{employee.email}</td>
              <td>{employee.doj}</td>
              <td>{employee.mobile}</td>
              <td>
                <Link to={`/update/${employee.id}`} className="btn btn-outline-warning">
                  Update
                </Link>
                &nbsp;&nbsp;
                <button className="btn btn-outline-danger" onClick={()=>onDelete(employee.id)} >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <br/>


      <button className="btn btn-danger" onClick={onLogout}>Logout</button>
    </div>
  );
};

export default EmployeeList;
