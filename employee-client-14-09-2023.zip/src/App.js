import "bootstrap/dist/css/bootstrap.min.css";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import EmployeeList from "./components/EmployeeList";
import AddEmployee from "./components/AddEmployee";
import RootLayout from "./components/RootLayout";
import Login from "./components/Login";
import DeleteEmployee from "./components/DeleteEmployee";
import UpdateEmployee from "./components/UpdateEmployee";

const router = createBrowserRouter([
  {
    path: "/",
    element: <RootLayout />,
    children: [
      {path:"/",element:<Login/>},
      { path: "/list", element: <EmployeeList /> },
      { path: "/add", element: <AddEmployee /> },
      {path:"/delete/:id",element:<DeleteEmployee/>},
      {path:"/update/:id",element:<UpdateEmployee/>}


    ],
  },
]);

function App() {
  return <RouterProvider router={router} />;
}

export default App;
