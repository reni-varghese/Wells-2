import "bootstrap/dist/css/bootstrap.min.css";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import EmployeeList from "./components/EmployeeList";
import AddEmployee from "./components/AddEmployee";
import RootLayout from "./components/RootLayout";

const router = createBrowserRouter([
  {
    path: "/",
    element: <RootLayout />,
    children: [
      { path: "/", element: <EmployeeList /> },
      { path: "/add", element: <AddEmployee /> },
    ],
  },
]);

function App() {
  return <RouterProvider router={router} />;
}

export default App;
