package org.reni;

import static org.hamcrest.CoreMatchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;

import org.hamcrest.Matchers;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.reni.entities.Employee;
import org.reni.security.JwtTokenProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest
@AutoConfigureMockMvc
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class EmployeeServiceApplicationTests {
	
	@Autowired
	private MockMvc mockMvc;
	
	private ObjectMapper objectMapper=new ObjectMapper();
	@Autowired
	private JwtTokenProvider jwtTokenProvider;
	

	@Test
	@Order(1)
	public void testGetAll() throws Exception {
		
		mockMvc.perform(get("/api/employees")).andExpect(status().isOk())
		.andExpect(jsonPath("$", Matchers.hasSize(6)));
		
	}
	@Order(2)
	@Test
	public void testGetById() throws Exception {
		mockMvc.perform(get("/api/employees/16")).andExpect(status().isOk())
		.andExpect(jsonPath("$.name", is("Suma Mathew")));
	}
	@Order(3)
	@Test
	@Disabled
	public void testAddEmployee() throws Exception {
		Employee employee=new Employee();
		employee.setName("Todd");
		employee.setGender("Male");
		employee.setAge(21);
		employee.setSalary(50000);
		employee.setEmail("tod@gmail.com");
		employee.setMobile("7654345678");
		
		UsernamePasswordAuthenticationToken authToken
			=new UsernamePasswordAuthenticationToken("sara", "pass");
		
		String jwt=jwtTokenProvider.generateToken(authToken);
		
		String jsonEmployee=objectMapper.writeValueAsString(employee);
		
		mockMvc.perform(post("/api/employees").content(jsonEmployee).
				contentType("application/json").header("Authorization", "Bearer "+jwt))
		.andExpect(status().isCreated());
		
	}
	@Test
	public void testUpdateEmployee() throws Exception {
		Employee employee=new Employee();
		employee.setId(13);
		employee.setName("Reni");
		employee.setGender("Male");
		employee.setEmail("reni.varghese@gmail.com");
		employee.setMobile("9449009170");
		employee.setAge(44);
		employee.setSalary(86000);
		
		String jsonEmployee=objectMapper.writeValueAsString(employee);
		
		mockMvc.perform(put("/api/employees/13").content(jsonEmployee)
				.contentType("application/json"))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$", is("Employee with id 13 updated successfully")));
		
	}
	@Test
	public void testGetByIdWhenProvidedWithAnInvalidId() throws Exception {
		
		mockMvc.perform(get("/api/employees/99"))
		.andExpect(status().isNotFound());
		
	}
	@Test
	public void testDelete() throws Exception {
		
		mockMvc.perform(delete("/api/employees/13"))
		.andExpect(status().isNoContent());
		
		mockMvc.perform(get("/api/employees/13"))
		.andExpect(status().isNotFound());
	}
	

}
