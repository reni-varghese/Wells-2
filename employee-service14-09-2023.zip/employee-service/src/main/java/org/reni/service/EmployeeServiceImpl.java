package org.reni.service;

import java.util.List;
import java.util.Optional;

import org.reni.entities.Employee;
import org.reni.exception.EmployeeAppException;
import org.reni.exception.EmployeeNotFoundException;
import org.reni.repositories.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
@Service
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Override
	public Employee addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return employeeRepository.save(employee);
	}

	@Override
	public List<Employee> getAll() {
		// TODO Auto-generated method stub
		return employeeRepository.findAll();
	}

	@Override
	public void deleteEmployee(int id) {
		Optional<Employee> optEmployee=employeeRepository.findById(id);
		if(!optEmployee.isPresent()) {
			throw new EmployeeNotFoundException("Employee with id "+id+" not found");
		}
		
		employeeRepository.deleteById(id);
		
	}

	@Override
	public Employee findEmployeeById(int id) {
		Employee employee=employeeRepository.findById(id)
				.orElseThrow(()->new EmployeeAppException(HttpStatus.NOT_FOUND, "Employee with Id "+id +" not found"));
		return employee;
	}

	@Override
	public String updateEmployee(int id, Employee employee) {
		employee.setId(id);
		employeeRepository.save(employee);
		
		return "Employee with id "+id+" updated successfully";
	}
	
	

}
