package org.reni.entities;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name="Employees")
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@Column(nullable =false)
	private String name;
	@Pattern(regexp = "(Male|Female)",message = "Gender should be either Male or Female")
	private String gender;
	@Max(value = 60,message = "Age Should be less than 60 and greater than 18")
	@Min(value = 18,message = "Age Should be less than 60 and greater than 18")
	private int age;
	private double salary;
	@Column(nullable = false,unique = true)
	@Email(message = "Invalid Email Id")
	private String email;
	private LocalDate doj;
	@Pattern(regexp = "[9876][0-9]{9}",message = "Mobile number should be of 10 digits")
	private String mobile;

}
