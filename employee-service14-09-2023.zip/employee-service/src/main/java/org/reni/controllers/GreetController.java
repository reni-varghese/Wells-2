package org.reni.controllers;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/greet")
@CrossOrigin
public class GreetController {

	@GetMapping("/hello")
	public String sayHello() {
		return "Hello from GET method";
	}
	
	@PostMapping("/hi")
	public String sayHi() {
		return "Hi from POST method";
	}
	@PreAuthorize("hasRole('ADMIN')")
	@PostMapping("/welcome")
	public String sayWelcome() {
		return "Welcome from Post method";
	}
}
