package org.reni.service;

import java.util.List;

import org.reni.entities.Employee;

public interface EmployeeService {

	Employee addEmployee(Employee employee);
	List<Employee> getAll();
}
