package org.reni.service;

import org.reni.entities.Employee;

public interface EmployeeService {

	Employee addEmployee(Employee employee);
}
