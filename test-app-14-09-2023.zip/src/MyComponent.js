import {useState} from "react";

const MyComponent=()=>{
    const [textChanged, setTextChanged] = useState(false);

    const handleButtonClick=()=>
        setTextChanged(true)
    return (
        <div>
            <h1>Hello from React!</h1>
            {!textChanged && <p>Welcome to React</p>}
            {textChanged && <p>Hi to React</p>}

            <br/>
            <button onClick={handleButtonClick}>Click Me</button>
        </div>
    )
}

export default MyComponent;